# Business Requirements Document (BRD)

## ClimaQ Pricing and Quotation Portal: climate risk assessment for Indian locations

[← Back to README](../README.md)

> Sample BA case study. The product context is inspired by a physical climate risk platform; all clients, prices and exposure levels are illustrative.

### Document control

| Field | Value |
|---|---|
| Document ID | CQ-BRD-001 |
| Version | 1.0 |
| Status | Draft for review |
| Prepared by | Kanika, Business Analyst |
| Date | 13 November 2026 |
| Reviewers | Head of Sustainability BU, Sales Head, Pricing Lead, Product Owner, Finance Controller |

### Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 0.1 | 03 Nov 2026 | Kanika | Initial draft from stakeholder workshops |
| 0.9 | 10 Nov 2026 | Kanika | Added pricing rules and approval matrix |
| 1.0 | 13 Nov 2026 | Kanika | Baseline for sign-off |

---

## Table of contents

1. [Executive summary](#1-executive-summary)
2. [Background and problem statement](#2-background-and-problem-statement)
3. [Business objectives](#3-business-objectives)
4. [Scope](#4-scope)
5. [Stakeholders](#5-stakeholders)
6. [Current state (as-is)](#6-current-state-as-is)
7. [Future state (to-be)](#7-future-state-to-be)
8. [Business requirements](#8-business-requirements)
9. [Pricing business rules](#9-pricing-business-rules)
10. [Assumptions, constraints and dependencies](#10-assumptions-constraints-and-dependencies)
11. [Risks](#11-risks)
12. [Success metrics](#12-success-metrics)
13. [Glossary](#13-glossary)
14. [Approvals](#14-approvals)

---

## 1. Executive summary

ClimaQ assesses how physical climate hazards (floods, cyclones, heat, drought, earthquakes, landslides and coastal inundation) affect specific locations. Today, quotes for ClimaQ assessments are built by hand in spreadsheets. Prices vary between sales executives, quotes take 3–5 working days, and nobody can see why one city costs more than another.

This BRD defines a **Pricing and Quotation Portal** that produces a consistent, explainable quote in minutes for any supported Indian city and any combination of hazards. The price reflects:

- **which hazards** the client wants assessed,
- **how exposed** each location is to each hazard (higher exposure means more modelling effort),
- **data availability** in the city (tier),
- whether the client wants **future climate scenarios**, and
- **how many locations** are in the request.

**Analogy:** a travel insurance website asks where you're going, for how long and which cover you want, then shows a price instantly with a breakdown. This portal does the same for climate risk assessments.

## 2. Background and problem statement

### 2.1 Background

Banks, insurers and manufacturers in India face growing pressure to measure physical climate risk: RBI's climate risk disclosure expectations for regulated entities, SEBI's BRSR Core for listed companies, and insurers' own underwriting needs. ClimaQ answers that need, but its sales process has not scaled with demand.

### 2.2 Problem statement

| # | Problem | Impact |
|---|---|---|
| P1 | Quotes are prepared manually in Excel | 3–5 day turnaround; deals lost to faster competitors |
| P2 | No standard rate card | The same request can get prices differing by 20–30% |
| P3 | Hazard exposure is not reflected in price | High-effort sites (e.g. Very high flood) are under-priced and erode margin |
| P4 | Discounts are given without approval | Revenue leakage; no audit trail |
| P5 | No record of quotes sent | Management cannot track pipeline or win rate |

## 3. Business objectives

| ID | Objective | Measure | Target |
|---|---|---|---|
| BO-1 | Faster quotes | Time from request to quote sent | Under 15 minutes for 1–49 locations |
| BO-2 | Consistent pricing | Variance between two quotes for the same request | 0% |
| BO-3 | Protect margin | Average discount given | No more than 10% |
| BO-4 | Transparent pricing for clients | Quotes showing a line-by-line breakdown | 100% |
| BO-5 | Pipeline visibility | Quotes tracked with status | 100% |

## 4. Scope

### 4.1 In scope

- Quotations for **17 Indian cities** at launch (see [PRICING.md](PRICING.md)), extendable by admin
- **7 hazards:** riverine and pluvial flood, cyclone and extreme wind, extreme heat, drought and water stress, earthquake, landslide, coastal inundation and sea-level rise
- Baseline climate and optional **SSP2-4.5 / SSP5-8.5** scenarios for 2030 and 2050
- Single-location and bulk (up to 49 locations) quotes
- Volume discounts, manual discount approvals, GST calculation
- Quote PDF, email, versioning, validity and status tracking
- Admin-maintained rate card and exposure matrix with audit trail
- Sales dashboard

### 4.2 Out of scope (phase 1)

- Running the hazard models themselves (the portal only prices them)
- Online payment and invoicing (handled in the existing ERP)
- Locations outside India
- 50+ location quotes (routed to Enterprise sales)
- Client self-service quoting (planned for phase 2)

## 5. Stakeholders

| Stakeholder | Role | Interest |
|---|---|---|
| Head of Sustainability BU | Sponsor | Revenue growth, margin |
| Sales Executive | Primary user | Fast, accurate quotes |
| Sales Manager | Approver | Discount control, pipeline view |
| Pricing Admin | Maintains rates | Easy updates, audit trail |
| Climate Risk Analyst | Subject matter expert | Exposure levels reflect modelling effort |
| Finance Controller | Reviewer | Correct GST, revenue recognition |
| Client (risk manager, underwriter, ESG lead) | Receives quote | Clear, comparable pricing |
| IT / Product team | Builds and runs the portal | Clear requirements, secure design |

## 6. Current state (as-is)

```
Client email → Sales exec reads request → Asks analyst which hazards apply
→ Builds Excel quote from an old template → Emails manager if discount needed
→ Waits for reply → Converts to PDF → Emails client
(3–5 working days, no central record)
```

## 7. Future state (to-be)

```
Sales exec enters locations (or uploads CSV) → Portal shows applicable hazards
→ Exec selects hazards and scenarios → Portal calculates price instantly
→ If extra discount requested, routed to approver automatically
→ Quote PDF generated with ID, breakdown and validity → Emailed to client
→ Status tracked (Draft, Pending approval, Sent, Accepted, Expired, Lost)
(Under 15 minutes, full audit trail)
```

## 8. Business requirements

Priority uses MoSCoW: **M** = Must, **S** = Should, **C** = Could.

| ID | Requirement | Priority | Source |
|---|---|:-:|---|
| BR-01 | The business must be able to quote for any supported Indian city, entered by name, address or coordinates. | M | Sales workshop |
| BR-02 | The client must be able to choose any combination of the 7 hazards per location; hazards that do not apply to a location (e.g. coastal inundation in Delhi) must not be offered. | M | Analyst team |
| BR-03 | The price of each hazard at each location must reflect that location's exposure level and the city's data-availability tier. | M | BU Head |
| BR-04 | The client must be able to add forward-looking climate scenarios for a defined uplift. | M | Product |
| BR-05 | Multi-location requests must receive a volume discount according to a published slab; 50+ locations go to Enterprise sales. | M | Sales Head |
| BR-06 | Every quote must show subtotal, discount, GST at the applicable rate and total in Indian Rupees. | M | Finance |
| BR-07 | Any discount beyond the standard slab must be approved according to an approval matrix. | M | Finance, Sales Head |
| BR-08 | Quotes must be produced as a branded PDF with a unique ID, line-item breakdown, assumptions and a 30-day validity, and must be shareable by email. | M | Sales |
| BR-09 | Authorised staff must be able to update base fees, multipliers, tiers and exposure levels without IT involvement, with every change logged. | M | Pricing Lead |
| BR-10 | Management must be able to see quotes by status, city, hazard, segment and value. | S | BU Head |
| BR-11 | Each quote should include a short risk preview (exposure level per hazard) so the client sees the value before buying. | S | Marketing |
| BR-12 | Access must be role-based, and client data must be protected. | M | IT Security |
| BR-13 | Revised quotes must keep version history. | S | Sales Manager |
| BR-14 | The portal could convert an accepted quote into a project request for the analyst team. | C | Delivery |

## 9. Pricing business rules

| Rule | Description |
|---|---|
| PR-1 | **Line price** = Hazard base fee × Exposure multiplier × City tier factor × (1 + Scenario uplift, if selected) |
| PR-2 | Base fees: Flood ₹18,000; Cyclone ₹15,000; Heat ₹10,000; Drought ₹12,000; Earthquake ₹14,000; Landslide ₹13,000; Coastal ₹16,000 |
| PR-3 | Exposure multipliers: Low 1.00, Moderate 1.15, High 1.35, Very high 1.60 |
| PR-4 | City tier factors: Tier 1 = 1.00, Tier 2 = 1.10, Tier 3 = 1.20 |
| PR-5 | Scenario uplift: +40% per line |
| PR-6 | Volume discount on the subtotal: 1–4 locations 0%; 5–19 = 10%; 20–49 = 15%; 50+ = Enterprise |
| PR-7 | Additional manual discount approval: up to 5% Sales Manager; above 5% up to 15% BU Head; above 15% not allowed |
| PR-8 | GST at 18% on the amount after discount |
| PR-9 | Line prices, discount and GST each rounded to the nearest ₹100 (half up) |
| PR-10 | Quotes are valid for 30 days and use the rate card in force on the issue date |
| PR-11 | Portfolio plan platform fee (₹3,00,000 per year) is billed separately from assessment lines |

Full rate card and worked quotes: [PRICING.md](PRICING.md).

## 10. Assumptions, constraints and dependencies

**Assumptions**
- A1. Exposure levels per city and hazard are supplied and reviewed by the Climate Risk Analyst team every quarter.
- A2. A location is priced using the city it falls in; sites outside a supported city's boundary are flagged for manual review.
- A3. GST rate is 18% for this service category (to be confirmed by Finance).

**Constraints**
- C1. Phase 1 must launch within one quarter.
- C2. Must use the company's existing SSO and email systems.
- C3. Client location data must be stored in India.

**Dependencies**
- D1. Geocoding service to convert addresses to coordinates.
- D2. Exposure matrix from the hazard modelling team.
- D3. CRM for client records.

## 11. Risks

| ID | Risk | Likelihood | Impact | Mitigation |
|---|---|:-:|:-:|---|
| R1 | Exposure levels become outdated | M | H | Quarterly review; effective-dated changes |
| R2 | Sales team keeps using Excel | M | M | Training; only portal quotes accepted by Finance |
| R3 | Clients see price differences between cities as unfair | L | M | Explain drivers in the quote PDF |
| R4 | Wrong GST treatment | L | H | Finance sign-off in UAT |

## 12. Success metrics

| KPI | Baseline | Target (6 months after launch) |
|---|---|---|
| Average quote turnaround | 3–5 days | Under 15 minutes |
| Quotes via portal | 0% | 95% |
| Average discount | ~18% (estimated) | No more than 10% |
| Quote-to-win rate | Not tracked | Tracked, with a target set after 3 months |

## 13. Glossary

| Term | Meaning |
|---|---|
| Assessment line | One hazard assessed at one location |
| Exposure level | How strongly a location is affected by a hazard (Low to Very high) |
| City tier | Grouping of cities by availability of climate and hazard data |
| SSP | Shared Socioeconomic Pathway, an IPCC future climate scenario (SSP2-4.5 is a middle path, SSP5-8.5 a high-emissions path) |
| BRSR | Business Responsibility and Sustainability Report required by SEBI |
| MoSCoW | Prioritisation method: Must, Should, Could, Won't |

## 14. Approvals

| Name | Role | Decision | Date |
|---|---|---|---|
| | Head of Sustainability BU | | |
| | Sales Head | | |
| | Finance Controller | | |
| | Product Owner | | |

Related documents: [FRS](FRS.md) · [User stories](USER-STORIES.md) · [UAT](UAT.md) · [Pricing](PRICING.md)
