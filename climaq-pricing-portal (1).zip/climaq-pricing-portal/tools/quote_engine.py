"""
ClimaQ Pricing & Quotation Engine (illustrative sample)

Generates:
  data/city-hazard-matrix.csv      - hazard exposure level per city
  data/rate-card.csv               - per-location price per city x hazard
  docs/PRICING.md                  - rate card + worked sample quotations

All prices are ILLUSTRATIVE for a BA portfolio case study.
They are not RMSI's actual commercial pricing.

Run:  python tools/quote_engine.py
"""
import csv
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ---------------------------------------------------------------------------
# 1. Configuration (in the real system these live in the Admin pricing table)
# ---------------------------------------------------------------------------
HAZARDS = {
    # code: (name, base fee per location in INR)
    "FL": ("Riverine & pluvial flood", 18000),
    "CY": ("Cyclone & extreme wind", 15000),
    "HT": ("Extreme heat", 10000),
    "DR": ("Drought & water stress", 12000),
    "EQ": ("Earthquake", 14000),
    "LS": ("Landslide", 13000),
    "CI": ("Coastal inundation & sea-level rise", 16000),
}

EXPOSURE_MULTIPLIER = {"L": 1.00, "M": 1.15, "H": 1.35, "VH": 1.60}
EXPOSURE_LABEL = {"L": "Low", "M": "Moderate", "H": "High", "VH": "Very high", "NA": "Not applicable"}

TIER_FACTOR = {1: 1.00, 2: 1.10, 3: 1.20}

SCENARIO_UPLIFT = 0.40  # adds SSP2-4.5 and SSP5-8.5 projections for 2030 and 2050

VOLUME_DISCOUNT = [  # (min locations, discount)
    (50, None),   # 50+ -> Enterprise, custom quote
    (20, 0.15),
    (5, 0.10),
    (1, 0.00),
]

GST_RATE = 0.18

# Hazard order: FL, CY, HT, DR, EQ, LS, CI.  Levels are ILLUSTRATIVE.
CITIES = {
    # city: (state, tier, [FL, CY, HT, DR, EQ, LS, CI])
    "Mumbai":         ("Maharashtra",       1, ["VH", "M",  "M",  "M",  "M",  "M",  "VH"]),
    "Delhi":          ("Delhi NCT",         1, ["H",  "L",  "VH", "H",  "H",  "L",  "NA"]),
    "Chennai":        ("Tamil Nadu",        1, ["VH", "H",  "H",  "H",  "M",  "L",  "VH"]),
    "Kolkata":        ("West Bengal",       1, ["VH", "H",  "H",  "L",  "M",  "L",  "H"]),
    "Bengaluru":      ("Karnataka",         1, ["M",  "L",  "M",  "H",  "L",  "L",  "NA"]),
    "Hyderabad":      ("Telangana",         1, ["H",  "L",  "H",  "H",  "L",  "L",  "NA"]),
    "Ahmedabad":      ("Gujarat",           1, ["M",  "M",  "VH", "H",  "M",  "L",  "NA"]),
    "Pune":           ("Maharashtra",       1, ["M",  "L",  "M",  "M",  "M",  "M",  "NA"]),
    "Surat":          ("Gujarat",           2, ["VH", "M",  "H",  "M",  "M",  "L",  "H"]),
    "Jaipur":         ("Rajasthan",         2, ["L",  "L",  "VH", "VH", "M",  "L",  "NA"]),
    "Bhubaneswar":    ("Odisha",            2, ["H",  "VH", "H",  "L",  "L",  "L",  "M"]),
    "Visakhapatnam":  ("Andhra Pradesh",    2, ["M",  "VH", "H",  "M",  "L",  "M",  "VH"]),
    "Kochi":          ("Kerala",            2, ["VH", "L",  "M",  "L",  "M",  "M",  "VH"]),
    "Guwahati":       ("Assam",             2, ["VH", "L",  "M",  "L",  "VH", "H",  "NA"]),
    "Dehradun":       ("Uttarakhand",       2, ["M",  "L",  "M",  "L",  "H",  "VH", "NA"]),
    "Bhuj":           ("Gujarat",           3, ["L",  "M",  "VH", "VH", "VH", "L",  "M"]),
    "Port Blair":     ("Andaman & Nicobar", 3, ["M",  "H",  "M",  "L",  "VH", "M",  "VH"]),
}

HAZARD_CODES = list(HAZARDS.keys())


def round100(x):
    return int(x / 100.0 + 0.5) * 100  # round half up


def unit_price(city, hz, scenarios=False):
    """Price for one hazard at one location (before discount and GST)."""
    _, tier, levels = CITIES[city]
    level = levels[HAZARD_CODES.index(hz)]
    if level == "NA":
        return None
    base = HAZARDS[hz][1]
    price = base * EXPOSURE_MULTIPLIER[level] * TIER_FACTOR[tier]
    if scenarios:
        price *= 1 + SCENARIO_UPLIFT
    return round100(price)


def volume_discount(n_locations):
    for min_n, disc in VOLUME_DISCOUNT:
        if n_locations >= min_n:
            return disc
    return 0.0


def build_quote(lines, scenarios):
    """lines: list of (site label, city, [hazard codes])."""
    rows, subtotal = [], 0
    for label, city, hzs in lines:
        for hz in hzs:
            p = unit_price(city, hz, scenarios)
            if p is None:
                rows.append((label, city, HAZARDS[hz][0], "Not applicable", 0))
                continue
            lvl = CITIES[city][2][HAZARD_CODES.index(hz)]
            rows.append((label, city, HAZARDS[hz][0], EXPOSURE_LABEL[lvl], p))
            subtotal += p
    n_loc = len(lines)
    disc = volume_discount(n_loc)
    if disc is None:
        raise ValueError("50+ locations: route to Enterprise sales")
    disc_amt = round100(subtotal * disc)
    taxable = subtotal - disc_amt
    gst = round100(taxable * GST_RATE)
    return {
        "rows": rows, "subtotal": subtotal, "disc": disc, "disc_amt": disc_amt,
        "taxable": taxable, "gst": gst, "total": taxable + gst, "n_loc": n_loc,
    }


def inr(n):
    """Indian digit grouping: 1234567 -> 12,34,567"""
    s = str(int(n))
    if len(s) <= 3:
        return "₹" + s
    head, tail = s[:-3], s[-3:]
    parts = []
    while len(head) > 2:
        parts.insert(0, head[-2:])
        head = head[:-2]
    if head:
        parts.insert(0, head)
    return "₹" + ",".join(parts) + "," + tail


SAMPLE_QUOTES = [
    {
        "id": "CQ-2026-0001",
        "client": "Coastal General Insurance (fictional)",
        "segment": "Insurer – underwriting a warehouse",
        "scenarios": True,
        "lines": [("Ennore warehouse", "Chennai", HAZARD_CODES)],
    },
    {
        "id": "CQ-2026-0002",
        "client": "Bharat Lending Bank (fictional)",
        "segment": "Bank – collateral portfolio screening",
        "scenarios": True,
        "lines": [
            ("Branch collateral A", "Mumbai", ["FL", "CY", "HT"]),
            ("Branch collateral B", "Delhi", ["FL", "CY", "HT"]),
            ("Branch collateral C", "Kolkata", ["FL", "CY", "HT"]),
            ("Branch collateral D", "Surat", ["FL", "CY", "HT"]),
            ("Branch collateral E", "Guwahati", ["FL", "CY", "HT"]),
        ],
    },
    {
        "id": "CQ-2026-0003",
        "client": "Western Auto Components (fictional)",
        "segment": "Manufacturer – plant resilience review",
        "scenarios": False,
        "lines": [
            ("Plant 1", "Ahmedabad", ["HT", "DR", "EQ"]),
            ("Plant 2", "Pune", ["HT", "DR", "EQ"]),
            ("Plant 3", "Bhuj", ["HT", "DR", "EQ"]),
        ],
    },
]


def write_csvs():
    os.makedirs(os.path.join(ROOT, "data"), exist_ok=True)
    with open(os.path.join(ROOT, "data", "city-hazard-matrix.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["city", "state", "tier"] + [HAZARDS[h][0] for h in HAZARD_CODES])
        for c, (st, tier, lv) in CITIES.items():
            w.writerow([c, st, tier] + [EXPOSURE_LABEL[x] for x in lv])
    with open(os.path.join(ROOT, "data", "rate-card.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["city", "tier", "hazard", "exposure", "price_current_inr", "price_with_scenarios_inr"])
        for c, (st, tier, lv) in CITIES.items():
            for h in HAZARD_CODES:
                p = unit_price(c, h)
                ps = unit_price(c, h, True)
                w.writerow([c, tier, HAZARDS[h][0], EXPOSURE_LABEL[lv[HAZARD_CODES.index(h)]],
                            p if p else "", ps if ps else ""])


def pricing_md():
    L = []
    a = L.append
    a("# ClimaQ pricing and quotations (India)")
    a("")
    a("> **Illustrative pricing for a BA case study.** All figures are sample values created to demonstrate "
      "requirements and a pricing model. They are not RMSI's commercial rates. Exposure levels are indicative "
      "and are not outputs of a hazard model.")
    a("")
    a("[← Back to README](../README.md)")
    a("")
    a("## 1. How a price is calculated")
    a("")
    a("Each hazard assessed at each location is one *assessment line*.")
    a("")
    a("```")
    a("Line price  = Hazard base fee × Exposure multiplier × City tier factor × (1 + Scenario uplift)")
    a("Subtotal    = Sum of all line prices")
    a("Discount    = Subtotal × Volume discount (by number of locations)")
    a("Total       = (Subtotal − Discount) + 18% GST")
    a("```")
    a("")
    a("Every line price, discount and GST amount is rounded to the nearest ₹100.")
    a("")
    a("**Analogy:** think of a car insurance premium. The base fee is the car model, the exposure "
      "multiplier is how risky the roads are, the tier factor is how hard it is to inspect the car, and "
      "the scenario uplift is buying extra cover for the future.")
    a("")
    a("### 1.1 Hazard base fees (per location)")
    a("")
    a("| Code | Hazard | Base fee |")
    a("|---|---|---:|")
    for h in HAZARD_CODES:
        a(f"| {h} | {HAZARDS[h][0]} | {inr(HAZARDS[h][1])} |")
    a("")
    a("### 1.2 Exposure multiplier")
    a("")
    a("A higher exposure needs finer-resolution modelling and analyst review, so it costs more.")
    a("")
    a("| Exposure level | Multiplier |")
    a("|---|---:|")
    for k in ["L", "M", "H", "VH"]:
        a(f"| {EXPOSURE_LABEL[k]} | {EXPOSURE_MULTIPLIER[k]:.2f} |")
    a("| Not applicable (e.g. coastal hazard for an inland city) | Not offered |")
    a("")
    a("### 1.3 City tier factor")
    a("")
    a("Reflects data availability. Tier 1 metros have dense observation networks; Tier 3 locations need more data acquisition and validation.")
    a("")
    a("| Tier | Factor | Cities in this sample |")
    a("|---|---:|---|")
    for t in (1, 2, 3):
        names = ", ".join(c for c, v in CITIES.items() if v[1] == t)
        a(f"| Tier {t} | {TIER_FACTOR[t]:.2f} | {names} |")
    a("")
    a("### 1.4 Climate scenario add-on")
    a("")
    a(f"Baseline (current climate) is included. Adding forward-looking projections under **SSP2-4.5** and "
      f"**SSP5-8.5** for **2030 and 2050** adds **{int(SCENARIO_UPLIFT*100)}%** to every line.")
    a("")
    a("### 1.5 Volume discount")
    a("")
    a("| Locations in one quote | Discount |")
    a("|---|---:|")
    a("| 1–4 | 0% |")
    a("| 5–19 | 10% |")
    a("| 20–49 | 15% |")
    a("| 50 or more | Enterprise plan, custom quote |")
    a("")
    a("## 2. Plans")
    a("")
    a("| Plan | Best for | What's included | Price |")
    a("|---|---|---|---|")
    a("| **Site Report** | One-off assessment of a few sites | PDF risk report per site, hazard scores, baseline climate | Pay per assessment line (rate card below) |")
    a("| **Portfolio** | Banks and insurers screening 5–49 sites | Dashboard for 5 users, Excel export, quarterly refresh, volume discount | ₹3,00,000 per year platform fee + assessment lines |")
    a("| **Enterprise** | 50+ sites, API integration | API access, SSO, custom hazards, dedicated analyst | Custom quote |")
    a("")
    a("## 3. Exposure matrix by city")
    a("")
    a("| City | State | Tier | " + " | ".join(HAZARD_CODES) + " |")
    a("|---|---|:-:|" + "|".join([":-:"] * len(HAZARD_CODES)) + "|")
    short = {"L": "L", "M": "M", "H": "H", "VH": "VH", "NA": "–"}
    for c, (st, tier, lv) in CITIES.items():
        a(f"| {c} | {st} | {tier} | " + " | ".join(short[x] for x in lv) + " |")
    a("")
    a("L = Low, M = Moderate, H = High, VH = Very high, – = Not applicable")
    a("")
    a("## 4. Rate card: price per location per hazard (baseline climate)")
    a("")
    a("| City | " + " | ".join(HAZARD_CODES) + " | All applicable hazards |")
    a("|---|" + "|".join(["---:"] * (len(HAZARD_CODES) + 1)) + "|")
    for c in CITIES:
        ps = [unit_price(c, h) for h in HAZARD_CODES]
        tot = sum(p for p in ps if p)
        a(f"| {c} | " + " | ".join(inr(p) if p else "–" for p in ps) + f" | **{inr(tot)}** |")
    a("")
    a("## 5. Rate card: with climate scenarios (SSP2-4.5 and SSP5-8.5, 2030 and 2050)")
    a("")
    a("| City | " + " | ".join(HAZARD_CODES) + " | All applicable hazards |")
    a("|---|" + "|".join(["---:"] * (len(HAZARD_CODES) + 1)) + "|")
    for c in CITIES:
        ps = [unit_price(c, h, True) for h in HAZARD_CODES]
        tot = sum(p for p in ps if p)
        a(f"| {c} | " + " | ".join(inr(p) if p else "–" for p in ps) + f" | **{inr(tot)}** |")
    a("")
    a("Prices exclude GST. Machine-readable version: [`data/rate-card.csv`](../data/rate-card.csv).")
    a("")
    a("## 6. Sample quotations")
    a("")
    a("All clients below are fictional.")
    for q in SAMPLE_QUOTES:
        r = build_quote(q["lines"], q["scenarios"])
        a("")
        a(f"### {q['id']}: {q['client']}")
        a("")
        a(f"- **Segment:** {q['segment']}")
        a(f"- **Locations:** {r['n_loc']}")
        a(f"- **Climate scenarios:** {'Yes (+40%)' if q['scenarios'] else 'No, baseline only'}")
        a(f"- **Validity:** 30 days from issue")
        a("- **Billing basis:** assessment lines only. The Portfolio plan platform fee, if chosen, is billed separately.")
        a("")
        a("| Site | City | Hazard | Exposure | Price |")
        a("|---|---|---|---|---:|")
        for site, city, hz, exp, p in r["rows"]:
            a(f"| {site} | {city} | {hz} | {exp} | {inr(p) if p else '–'} |")
        a(f"| | | | **Subtotal** | **{inr(r['subtotal'])}** |")
        a(f"| | | | Volume discount ({int(r['disc']*100)}%) | −{inr(r['disc_amt'])} |")
        a(f"| | | | Taxable amount | {inr(r['taxable'])} |")
        a(f"| | | | GST (18%) | {inr(r['gst'])} |")
        a(f"| | | | **Total payable** | **{inr(r['total'])}** |")
    a("")
    a("## 7. Worked example (one line)")
    a("")
    p = unit_price("Chennai", "FL", True)
    a("Flood at Chennai with scenarios:")
    a("")
    a("```")
    a("₹18,000 (flood base) × 1.60 (Very high) × 1.00 (Tier 1) × 1.40 (scenarios)")
    a(f"= ₹40,320 → rounded to {inr(p)}")
    a("```")
    a("")
    a("_Regenerate this page after changing any rate with `python tools/quote_engine.py`._")
    a("")
    with open(os.path.join(ROOT, "docs", "PRICING.md"), "w") as f:
        f.write("\n".join(L))


if __name__ == "__main__":
    os.makedirs(os.path.join(ROOT, "docs"), exist_ok=True)
    write_csvs()
    pricing_md()
    for q in SAMPLE_QUOTES:
        r = build_quote(q["lines"], q["scenarios"])
        print(q["id"], "subtotal", r["subtotal"], "disc", r["disc_amt"], "gst", r["gst"], "total", r["total"])
