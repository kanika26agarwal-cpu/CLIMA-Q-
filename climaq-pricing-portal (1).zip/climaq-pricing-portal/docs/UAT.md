# User acceptance testing (UAT)

## ClimaQ Pricing and Quotation Portal

[← Back to README](../README.md)

**What UAT is:** the final check where real business users (not developers) confirm the system does what the business asked for. **Analogy:** the developer built the house and the engineer checked the wiring; UAT is the family walking through before moving in, turning on every tap.

| Field | Value |
|---|---|
| Document ID | CQ-UAT-001 |
| Version | 1.0 |
| Prepared by | Kanika, Business Analyst |
| Test environment | UAT (`uat.climaq-pricing.internal`, illustrative) |
| Test data | Rate card v1.0 and exposure matrix v1.0, as in [PRICING.md](PRICING.md) |

---

## 1. Entry criteria

- All Must-have user stories are development-complete and passed system testing.
- No open Critical or High defects from system testing.
- UAT environment loaded with rate card v1.0, 17 cities and test users for every role.
- Testers have attended a 30-minute walkthrough.

## 2. Exit criteria

- 100% of test cases executed.
- 100% of Must-have test cases passed.
- No open Critical or High defects; Medium defects have an agreed fix date.
- All calculated totals match the reference engine (`tools/quote_engine.py`) to the rupee.
- Sign-off from Sales Head, Finance Controller and Product Owner.

## 3. Defect severity

| Severity | Definition | Example |
|---|---|---|
| Critical | Wrong money or data breach | GST calculated on the pre-discount amount |
| High | Key function blocked, no workaround | Cannot send PDF |
| Medium | Function works with workaround | CSV error message unclear |
| Low | Cosmetic | Misaligned logo on PDF |

## 4. User acceptance criteria (summary)

The portal is accepted when the business confirms that:

1. **Accuracy:** every price, discount, GST and total matches the published rate card and formula.
2. **Speed:** a single-site quote is created and sent in under 5 minutes; a 49-site CSV quote in under 15 minutes.
3. **Relevance:** hazards that don't apply to a location cannot be quoted.
4. **Control:** no discount above the standard slab reaches a client without the right approval.
5. **Transparency:** every quote PDF shows a line-by-line breakdown, risk preview, validity and page numbers.
6. **Auditability:** every rate change and approval is logged with who, when, what and why.
7. **Security:** users see only the quotes their role allows.

## 5. Test cases

Status column is filled during execution: Pass / Fail / Blocked.

| TC | Story | Scenario | Steps | Expected result | Status |
|---|---|---|---|---|---|
| TC-01 | US-01 | Search city | Type "Che" in city search | "Chennai, Tamil Nadu (Tier 1)" suggested | |
| TC-02 | US-01 | Unsupported city | Enter "Shillong" | Error E-01 and "Request manual review" shown | |
| TC-03 | US-02 | Address in Mumbai | Enter a Mumbai address | Mapped to Mumbai, pin shown on map | |
| TC-04 | US-02 | Coordinates outside India | Enter 27.7172, 85.3240 (Kathmandu) | Error E-02 | |
| TC-05 | US-03 | CSV with 50 rows | Upload 50-row template | Message E-04; Sales Manager receives Enterprise notification | |
| TC-06 | US-04 | Not-applicable hazard | Add Delhi; view hazards | Coastal inundation disabled with tooltip | |
| TC-07 | US-04 | Select all | Add Chennai; click "Select all applicable" | All 7 hazards selected | |
| TC-08 | US-04 | No hazard | Add Pune; select none; click Calculate | Error E-05 naming the Pune site | |
| TC-09 | US-05 | Tier 1 line price | Chennai + Flood, scenarios off | Line = ₹28,800 | |
| TC-10 | US-05 | Tier 2 and Tier 3 line prices | Jaipur + Heat; Port Blair + Earthquake; scenarios off | Jaipur Heat = ₹17,600; Port Blair Earthquake = ₹26,900 | |
| TC-11 | US-06 | Scenario uplift | Chennai + Flood; switch scenarios on | Line changes ₹28,800 → ₹40,300 | |
| TC-12 | US-07 | No discount under 5 sites | Heat only at Mumbai, Delhi, Pune, Jaipur | Subtotal ₹56,600; discount ₹0 | |
| TC-13 | US-07 | 15% slab | 20 sites, all Pune, Heat only, scenarios off | Subtotal ₹2,30,000; discount ₹34,500; total ₹2,30,700 | |
| TC-14 | US-07 | GST on discounted amount | Recreate CQ-2026-0002 (5 sites, Flood + Cyclone + Heat, scenarios on) | Subtotal ₹4,22,600; discount ₹42,300; GST ₹68,500; total ₹4,48,800 | |
| TC-15 | US-08 | Route 5% to manager | Request 5% with valid reason | Status "Pending approval"; Sales Manager notified | |
| TC-16 | US-08 | Route 12% to BU Head | Request 12% | Request appears in BU Head's inbox, not the manager's | |
| TC-17 | US-08 | Block above 15% | Request 18% | Error E-07; no request created | |
| TC-18 | US-09 | Approve 5% | Manager approves 5% on TC-14 quote | Manual discount ₹19,000; GST ₹65,000; total ₹4,26,300 | |
| TC-19 | US-10 | PDF content | Generate PDF for TC-14 quote | ID format CQ-YYYY-NNNN; issue and expiry (+30 days); line items; totals; terms; page numbers | |
| TC-20 | US-10 | Email and status | Email PDF to a test client | Status "Sent"; email logged | |
| TC-21 | US-10 | Auto-expiry | Set system date to 31 days after issue; run nightly job | Status "Expired" | |
| TC-22 | US-11 | Effective-dated rate | Change Flood base to ₹19,000 effective tomorrow; create quote today | Quote uses ₹18,000; audit log entry present | |
| TC-23 | US-11 | Invalid exposure upload | Upload matrix with level "Extreme" | Row rejected; matrix not activated | |
| TC-24 | US-12 | Dashboard filter and export | Filter "Insurer", last 90 days; export | Widgets update; .xlsx matches screen | |
| TC-25 | US-13 | Risk preview | Generate PDF for a Guwahati site | Flood: Very high; Earthquake: Very high; Landslide: High; disclaimer shown | |
| TC-26 | US-14 | Role visibility | Sign in as Sales Executive B | Cannot see Sales Executive A's quotes | |
| TC-27 | US-15 | Versioning | Revise a sent quote and resend | v1 read-only; history shows v1 and v2 with totals | |

## 6. Defect log (template)

| Defect ID | TC | Severity | Description | Raised by | Assigned to | Status |
|---|---|---|---|---|---|---|
| | | | | | | |

## 7. Sign-off

| Name | Role | Decision (Accept / Accept with conditions / Reject) | Date |
|---|---|---|---|
| | Sales Head | | |
| | Finance Controller | | |
| | Product Owner | | |
| | Head of Sustainability BU | | |

Related documents: [BRD](BRD.md) · [FRS](FRS.md) · [User stories](USER-STORIES.md) · [Pricing](PRICING.md)
