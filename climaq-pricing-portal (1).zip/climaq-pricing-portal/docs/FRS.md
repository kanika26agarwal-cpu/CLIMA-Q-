# Functional Requirements Specification (FRS)

## ClimaQ Pricing and Quotation Portal

[← Back to README](../README.md)

### Document control

| Field | Value |
|---|---|
| Document ID | CQ-FRS-001 |
| Version | 1.0 |
| Status | Draft for review |
| Prepared by | Kanika, Business Analyst |
| Date | 13 November 2026 |
| Parent document | [CQ-BRD-001](BRD.md) |

**BRD vs FRS, in one line:** the BRD says *what the business needs and why*; the FRS says *exactly how the system must behave* so developers can build it and testers can check it. If the BRD is the restaurant owner saying "we need a faster lunch menu", the FRS is the recipe card each cook follows.

---

## Table of contents

1. [Introduction](#1-introduction)
2. [System overview](#2-system-overview)
3. [User roles and permissions](#3-user-roles-and-permissions)
4. [Functional requirements](#4-functional-requirements)
5. [Pricing calculation specification](#5-pricing-calculation-specification)
6. [Quote lifecycle](#6-quote-lifecycle)
7. [Data requirements](#7-data-requirements)
8. [Interface requirements](#8-interface-requirements)
9. [Non-functional requirements](#9-non-functional-requirements)
10. [Validation and error messages](#10-validation-and-error-messages)
11. [Traceability matrix](#11-traceability-matrix)

---

## 1. Introduction

### 1.1 Purpose
This document specifies the functional behaviour of the ClimaQ Pricing and Quotation Portal described in the BRD.

### 1.2 Audience
Developers, QA testers, the Product Owner, Pricing Admin and UAT participants.

### 1.3 Conventions
- "**shall**" = mandatory; "**should**" = recommended.
- IDs: `FR-xx` functional, `NFR-xx` non-functional, `BR-xx` business requirement, `US-xx` user story, `TC-xx` test case.

## 2. System overview

### 2.1 Inputs and outputs

| Inputs | Processing | Outputs |
|---|---|---|
| Client details | Location matching to supported city | Quote with unique ID |
| Locations (city, address, coordinates or CSV) | Hazard applicability check | Line-item price breakdown |
| Selected hazards | Price calculation (rate card × exposure × tier × scenario) | Risk preview (exposure per hazard) |
| Scenario option | Volume discount, manual discount, GST | Branded PDF and email |
| Manual discount request | Approval routing | Dashboard and audit log |

### 2.2 Context diagram

```
            ┌──────────────┐        ┌───────────────────┐
 Sales ───► │              │ ─────► │ Geocoding service │
 Manager ─► │   ClimaQ     │ ◄───── └───────────────────┘
 Admin ───► │   Pricing    │        ┌───────────────────┐
            │   Portal     │ ─────► │ CRM (client data) │
 Client ◄── │              │        └───────────────────┘
 (PDF/email)│              │        ┌───────────────────┐
            │              │ ─────► │ Email / SSO       │
            └──────────────┘        └───────────────────┘
```

## 3. User roles and permissions

| Function | Sales Executive | Sales Manager | BU Head | Pricing Admin | Finance (read) |
|---|:-:|:-:|:-:|:-:|:-:|
| Create / edit draft quote | ✓ | ✓ | | | |
| Apply standard volume discount | Auto | Auto | | | |
| Request manual discount | ✓ | ✓ | | | |
| Approve manual discount up to 5% | | ✓ | ✓ | | |
| Approve manual discount above 5% up to 15% | | | ✓ | | |
| Send quote to client | ✓ | ✓ | | | |
| Edit rate card / exposure matrix | | | | ✓ | |
| View audit log | | ✓ | ✓ | ✓ | ✓ |
| View dashboard | Own quotes | Team | All | All | All |

## 4. Functional requirements

### 4.1 Location capture (BR-01)

| ID | Requirement |
|---|---|
| FR-01 | The system shall let the user select a city from a searchable list of supported cities, showing state and tier. |
| FR-02 | The system shall accept a full address or latitude/longitude, geocode it, and map it to the supported city whose boundary contains the point. |
| FR-03 | If a point falls outside every supported city boundary, the system shall flag the location "Manual review" and exclude it from automatic pricing. |
| FR-04 | The system shall reject coordinates outside India with error E-02. |
| FR-05 | The system shall accept a CSV upload (columns: `site_name, address, latitude, longitude, hazards`) of 1–49 rows and show a row-by-row validation report before pricing. |
| FR-06 | The system shall route uploads of 50 or more locations to the Enterprise queue and notify the Sales Manager. |

### 4.2 Hazard selection (BR-02, BR-11)

| ID | Requirement |
|---|---|
| FR-07 | For each location, the system shall list all 7 hazards with the exposure level from the active exposure matrix. |
| FR-08 | Hazards with exposure "Not applicable" shall be shown greyed out with the tooltip "This hazard does not apply at this location" and cannot be selected. |
| FR-09 | The system shall offer a "Select all applicable hazards" option per location and for all locations at once. |
| FR-10 | At least one hazard must be selected per location before a price is shown (error E-05). |

### 4.3 Pricing engine (BR-03, BR-04, BR-05, BR-06)

| ID | Requirement |
|---|---|
| FR-11 | The system shall calculate each line price using the formula in [section 5](#5-pricing-calculation-specification). |
| FR-12 | The system shall provide a quote-level toggle "Include climate scenarios (SSP2-4.5 and SSP5-8.5, 2030 and 2050)" that applies the scenario uplift to every line. |
| FR-13 | The system shall apply the volume discount slab automatically based on the number of priced locations. |
| FR-14 | The system shall calculate GST on the amount after all discounts. |
| FR-15 | The system shall recalculate and display the price within 2 seconds of any change to locations, hazards or options. |
| FR-16 | The system shall show a price breakdown with base fee, exposure multiplier, tier factor and scenario uplift for every line ("Why this price?"). |
| FR-17 | The system shall use the rate card version in force on the quote creation date and store that version ID with the quote. |

### 4.4 Discounts and approvals (BR-07)

| ID | Requirement |
|---|---|
| FR-18 | The user may request an additional manual discount in whole percentages with a mandatory reason (minimum 20 characters). |
| FR-19 | Requests up to 5% shall route to the Sales Manager; above 5% up to 15% to the BU Head; above 15% shall be blocked with error E-07. |
| FR-20 | While approval is pending the quote status shall be "Pending approval" and the quote cannot be sent. |
| FR-21 | Approvers shall receive an email and in-app notification and can approve, reject (reason mandatory) or approve a lower percentage. |
| FR-22 | If no action is taken within 2 working days, the system shall send a reminder to the approver and copy their manager. |

### 4.5 Quote document (BR-08, BR-13)

| ID | Requirement |
|---|---|
| FR-23 | The system shall assign a unique quote ID in the format `CQ-YYYY-NNNN` (sequential per year). |
| FR-24 | The system shall generate a PDF containing: client details, quote ID and version, issue and expiry dates, line items, risk preview, subtotal, discounts, GST, total, assumptions, terms and page numbers. |
| FR-25 | The validity date shall be issue date + 30 calendar days. |
| FR-26 | The user shall be able to email the PDF from the portal to one or more client addresses, with the send logged. |
| FR-27 | Editing a sent quote shall create a new version (v2, v3…) and keep earlier versions read-only. |
| FR-28 | The system shall set status to "Expired" automatically after the validity date unless status is "Accepted". |
| FR-29 | The user shall be able to mark a quote "Accepted" or "Lost" (loss reason mandatory). |

### 4.6 Administration (BR-09)

| ID | Requirement |
|---|---|
| FR-30 | The Pricing Admin shall be able to edit hazard base fees, exposure multipliers, tier factors, scenario uplift, volume slabs and GST rate, each with an effective-from date. |
| FR-31 | The Pricing Admin shall be able to add cities, change a city's tier and upload a new exposure matrix CSV, which is validated before activation. |
| FR-32 | Every admin change shall be written to an audit log with user, timestamp, old value, new value and reason. |
| FR-33 | Changes shall not alter the price of quotes already issued. |

### 4.7 Reporting (BR-10)

| ID | Requirement |
|---|---|
| FR-34 | The dashboard shall show number and value of quotes by status, city, hazard, client segment and sales executive, filterable by date range. |
| FR-35 | The dashboard shall show win rate, average discount and average turnaround time. |
| FR-36 | All dashboard tables shall be exportable to Excel (.xlsx). |

### 4.8 Security and access (BR-12)

| ID | Requirement |
|---|---|
| FR-37 | Users shall sign in through company SSO; access is controlled by the roles in section 3. |
| FR-38 | Sales Executives shall see only their own quotes; managers see their team's. |

### 4.9 Handover (BR-14, could-have)

| ID | Requirement |
|---|---|
| FR-39 | On "Accepted", the system could create a project request for the analyst team containing locations and hazards. |

## 5. Pricing calculation specification

### 5.1 Formula

```
For each location L and selected hazard H:
    line(L,H) = ROUND100( BaseFee[H] × ExposureMult[Exposure(L,H)] × TierFactor[Tier(L)]
                          × (1 + ScenarioUplift if scenarios selected else 1) )

Subtotal       = Σ line(L,H)
VolumeDisc     = ROUND100( Subtotal × Slab(count of priced locations) )
ManualDisc     = ROUND100( (Subtotal − VolumeDisc) × ApprovedManualPct )
Taxable        = Subtotal − VolumeDisc − ManualDisc
GST            = ROUND100( Taxable × GSTRate )
Total          = Taxable + GST

ROUND100(x) = round to nearest ₹100, halves rounded up
```

### 5.2 Parameter values at launch

| Parameter | Value |
|---|---|
| Base fees | Flood 18,000; Cyclone 15,000; Heat 10,000; Drought 12,000; Earthquake 14,000; Landslide 13,000; Coastal 16,000 (INR) |
| Exposure multiplier | Low 1.00; Moderate 1.15; High 1.35; Very high 1.60 |
| Tier factor | Tier 1 = 1.00; Tier 2 = 1.10; Tier 3 = 1.20 |
| Scenario uplift | 0.40 |
| Volume slab | 1–4: 0%; 5–19: 10%; 20–49: 15%; 50+: Enterprise |
| GST | 18% |

### 5.3 Worked example

Flood, Surat (Very high, Tier 2), with scenarios:
`18,000 × 1.60 × 1.10 × 1.40 = 44,352 → ₹44,400`

A reference implementation is in [`tools/quote_engine.py`](../tools/quote_engine.py). Test cases in [UAT.md](UAT.md) use its outputs as expected values.

## 6. Quote lifecycle

```
Draft ──► Pending approval ──► Approved ──► Sent ──► Accepted
  │             │                             │
  │             └──► Rejected ──► Draft       ├──► Lost
  └────────────────────────────────► Sent     └──► Expired (after 30 days)
       (no manual discount)
```

| From | To | Trigger |
|---|---|---|
| Draft | Pending approval | Manual discount requested |
| Draft | Sent | Sent with no manual discount |
| Pending approval | Approved / Rejected | Approver action |
| Approved | Sent | User sends |
| Sent | Accepted / Lost | User updates |
| Sent | Expired | System, validity date passed |
| Any sent state | New version (Draft) | User edits |

## 7. Data requirements

| Entity | Key fields |
|---|---|
| Client | client_id, name, segment (Bank / Insurer / Manufacturer / Other), GSTIN, contact email, CRM ID |
| City | city_id, name, state, tier, boundary polygon, active flag |
| Hazard | hazard_code, name, base_fee, active flag |
| ExposureMatrix | city_id, hazard_code, exposure_level, effective_from, version |
| RateCard | version, multipliers, tier factors, scenario uplift, slabs, GST, effective_from |
| Quote | quote_id, version, client_id, created_by, status, scenario_flag, rate_card_version, subtotal, volume_disc, manual_disc, gst, total, issue_date, expiry_date |
| QuoteLine | quote_id, version, site_name, city_id, lat, lon, hazard_code, exposure_level, line_price |
| Approval | quote_id, requested_pct, reason, approver, decision, decided_pct, timestamp |
| AuditLog | entity, field, old_value, new_value, user, timestamp, reason |

## 8. Interface requirements

| Interface | Direction | Purpose |
|---|---|---|
| Geocoding API | Out/In | Address → coordinates |
| CRM | In | Client lookup |
| Email service | Out | Send quote and notifications |
| SSO (SAML / OIDC) | In | Authentication |
| Pricing API (internal, phase 2) | In/Out | `POST /quotes/price` returns line items and totals, for future client self-service |

## 9. Non-functional requirements

| ID | Category | Requirement |
|---|---|---|
| NFR-01 | Performance | Price recalculation in under 2 seconds for up to 49 locations × 7 hazards |
| NFR-02 | Performance | PDF generation in under 10 seconds |
| NFR-03 | Availability | 99.5% during business hours (09:00–19:00 IST, Mon–Sat) |
| NFR-04 | Security | Data encrypted in transit (TLS 1.2+) and at rest; hosted in India |
| NFR-05 | Audit | Audit logs kept for 7 years and cannot be edited |
| NFR-06 | Usability | A new sales user can create a single-site quote in under 5 minutes after a 30-minute training |
| NFR-07 | Compatibility | Latest two versions of Chrome and Edge; usable on a 1366×768 screen |
| NFR-08 | Accuracy | Calculated totals match the reference engine to the rupee |
| NFR-09 | Localisation | Currency in Indian digit grouping (₹1,23,456); dates DD-MMM-YYYY |

## 10. Validation and error messages

| Code | Condition | Message shown |
|---|---|---|
| E-01 | City not in list | "We don't price this city yet. Choose a nearby supported city or request manual review." |
| E-02 | Coordinates outside India | "This location is outside India. ClimaQ quotes cover Indian locations only." |
| E-03 | CSV missing columns | "Your file is missing these columns: {list}. Download the template and try again." |
| E-04 | More than 49 rows | "Quotes for 50 or more locations are handled by Enterprise sales. We've sent your request to them." |
| E-05 | No hazard selected | "Select at least one hazard for {site name}." |
| E-06 | Discount reason too short | "Add a reason of at least 20 characters." |
| E-07 | Manual discount above 15% | "Discounts above 15% aren't allowed. Enter 15% or less." |
| E-08 | Send attempted while pending | "This quote is waiting for discount approval and can't be sent yet." |

## 11. Traceability matrix

| BR | FR | User story | UAT test cases |
|---|---|---|---|
| BR-01 | FR-01 – FR-06 | US-01, US-02, US-03 | TC-01 – TC-05 |
| BR-02 | FR-07 – FR-10 | US-04 | TC-06 – TC-08 |
| BR-03 | FR-11, FR-16, FR-17 | US-05 | TC-09, TC-10 |
| BR-04 | FR-12 | US-06 | TC-11 |
| BR-05 | FR-13 | US-07 | TC-12, TC-13 |
| BR-06 | FR-14 | US-07 | TC-14 |
| BR-07 | FR-18 – FR-22 | US-08, US-09 | TC-15 – TC-18 |
| BR-08 | FR-23 – FR-26, FR-28, FR-29 | US-10 | TC-19 – TC-21 |
| BR-09 | FR-30 – FR-33 | US-11 | TC-22, TC-23 |
| BR-10 | FR-34 – FR-36 | US-12 | TC-24 |
| BR-11 | FR-07, FR-24 | US-13 | TC-25 |
| BR-12 | FR-37, FR-38 | US-14 | TC-26 |
| BR-13 | FR-27 | US-15 | TC-27 |
| BR-14 | FR-39 | (Phase 2 backlog) | (Phase 2) |

Related documents: [BRD](BRD.md) · [User stories](USER-STORIES.md) · [UAT](UAT.md) · [Pricing](PRICING.md)
