# User stories

## ClimaQ Pricing and Quotation Portal

[← Back to README](../README.md)

Format: **As a** *role*, **I want** *capability*, **so that** *benefit*.
Acceptance criteria use **Given / When / Then**.
Estimates are in story points (1, 2, 3, 5, 8). Priority uses MoSCoW.

**Analogy:** a user story is a short order slip ("Table 4 wants a vegetarian thali, no onions"). The acceptance criteria are the checklist the waiter uses before serving: if each item is ticked, the order is done.

### Story map

| Epic | Stories |
|---|---|
| E1. Capture locations | US-01, US-02, US-03 |
| E2. Choose hazards and options | US-04, US-06, US-13 |
| E3. Calculate price | US-05, US-07 |
| E4. Approvals | US-08, US-09 |
| E5. Issue and track quotes | US-10, US-15 |
| E6. Administration and reporting | US-11, US-12, US-14 |

---

### US-01: Quote a single city
**As a** Sales Executive, **I want** to pick a supported Indian city from a searchable list, **so that** I can start a quote in seconds.

| Field | Value |
|---|---|
| Priority | Must |
| Points | 2 |
| Traces to | BR-01, FR-01 |

**Acceptance criteria**
1. **Given** I am on "New quote", **when** I type "Che", **then** I see "Chennai, Tamil Nadu (Tier 1)" in the suggestions.
2. **Given** I select Chennai, **when** the location is added, **then** its tier and the 7 hazards with exposure levels are displayed.
3. **Given** I type a city that is not supported, **when** I press Enter, **then** I see error E-01 and the "Request manual review" button.

---

### US-02: Quote by address or coordinates
**As a** Sales Executive, **I want** to enter a site address or latitude/longitude, **so that** I can price the client's exact facility, not just the city.

| Field | Value |
|---|---|
| Priority | Must |
| Points | 5 |
| Traces to | BR-01, FR-02 – FR-04 |

**Acceptance criteria**
1. **Given** I enter an address inside Mumbai, **when** it is geocoded, **then** the site is mapped to Mumbai and shows its coordinates on a map pin.
2. **Given** I enter coordinates outside all supported city boundaries but inside India, **when** I add the site, **then** it is flagged "Manual review" and not priced.
3. **Given** I enter coordinates outside India, **when** I add the site, **then** I see error E-02.

---

### US-03: Upload many locations at once
**As a** Sales Executive at a bank, **I want** to upload a CSV of collateral locations, **so that** I don't type 40 sites one by one.

| Field | Value |
|---|---|
| Priority | Must |
| Points | 8 |
| Traces to | BR-01, FR-05, FR-06 |

**Acceptance criteria**
1. **Given** a valid CSV with 1–49 rows, **when** I upload it, **then** I see a validation report showing valid rows, rows needing review, and errors per row.
2. **Given** the CSV is missing the `latitude` column and has no address, **when** I upload it, **then** I see error E-03 naming the missing column.
3. **Given** the CSV has 50 or more rows, **when** I upload it, **then** I see message E-04 and the Sales Manager receives an Enterprise notification.
4. **Given** I can download a CSV template, **when** I open it, **then** it contains the columns `site_name, address, latitude, longitude, hazards`.

---

### US-04: Select only relevant hazards
**As a** Sales Executive, **I want** the portal to show which hazards apply at each site and disable the ones that don't, **so that** I never quote coastal inundation for Delhi.

| Field | Value |
|---|---|
| Priority | Must |
| Points | 3 |
| Traces to | BR-02, FR-07 – FR-10 |

**Acceptance criteria**
1. **Given** a Delhi site, **when** I view hazards, **then** "Coastal inundation and sea-level rise" is greyed out with the tooltip "This hazard does not apply at this location".
2. **Given** a Chennai site, **when** I click "Select all applicable hazards", **then** all 7 hazards are selected.
3. **Given** a site with no hazard selected, **when** I click "Calculate", **then** I see error E-05 naming that site.

---

### US-05: See a fair, explained price per hazard
**As a** client risk manager, **I want** to see why each hazard at each site costs what it does, **so that** I trust the quote and can justify it to my CFO.

| Field | Value |
|---|---|
| Priority | Must |
| Points | 5 |
| Traces to | BR-03, FR-11, FR-16, FR-17 |

**Acceptance criteria**
1. **Given** Flood at Chennai (Very high, Tier 1) with no scenarios, **when** the price is calculated, **then** the line shows ₹28,800.
2. **Given** I click "Why this price?", **when** the panel opens, **then** it shows base fee ₹18,000 × exposure 1.60 × tier 1.00 = ₹28,800.
3. **Given** the rate card changed after the quote was created, **when** I reopen the quote, **then** prices remain those of the original rate card version.

---

### US-06: Add future climate scenarios
**As an** insurance underwriter, **I want** to add 2030 and 2050 projections under SSP2-4.5 and SSP5-8.5, **so that** I can price risk for multi-year policies.

| Field | Value |
|---|---|
| Priority | Must |
| Points | 2 |
| Traces to | BR-04, FR-12 |

**Acceptance criteria**
1. **Given** a quote with Flood at Chennai, **when** I switch on "Include climate scenarios", **then** the line changes from ₹28,800 to ₹40,300.
2. **Given** scenarios are on, **when** I generate the PDF, **then** it lists "SSP2-4.5 and SSP5-8.5, 2030 and 2050" under scope.

---

### US-07: Get volume discounts and correct GST automatically
**As a** Sales Executive, **I want** volume discounts and GST applied automatically, **so that** I don't make calculation mistakes.

| Field | Value |
|---|---|
| Priority | Must |
| Points | 3 |
| Traces to | BR-05, BR-06, FR-13, FR-14 |

**Acceptance criteria**
1. **Given** 4 priced locations, **when** the quote is calculated, **then** the volume discount is 0%.
2. **Given** 5 priced locations with subtotal ₹4,22,600, **when** calculated, **then** volume discount is ₹42,300 (10%), GST is ₹68,500 and total is ₹4,48,800.
3. **Given** 20 priced locations, **when** calculated, **then** the discount is 15%.
4. **Given** a location flagged "Manual review", **when** counting locations for the slab, **then** it is not counted.

---

### US-08: Request an extra discount
**As a** Sales Executive, **I want** to request an extra discount with a reason, **so that** I can close a competitive deal within policy.

| Field | Value |
|---|---|
| Priority | Must |
| Points | 3 |
| Traces to | BR-07, FR-18 – FR-20 |

**Acceptance criteria**
1. **Given** a draft quote, **when** I request 5% with a reason of at least 20 characters, **then** status changes to "Pending approval" and the Sales Manager is notified.
2. **Given** I request 12%, **when** I submit, **then** the request goes to the BU Head.
3. **Given** I request 18%, **when** I submit, **then** I see error E-07.
4. **Given** status is "Pending approval", **when** I click "Send", **then** I see error E-08.

---

### US-09: Approve or reject discounts quickly
**As a** Sales Manager, **I want** to approve, reject or reduce discount requests from my inbox, **so that** deals aren't delayed and margin is protected.

| Field | Value |
|---|---|
| Priority | Must |
| Points | 3 |
| Traces to | BR-07, FR-21, FR-22 |

**Acceptance criteria**
1. **Given** a 5% request on quote CQ-2026-0002, **when** I approve, **then** the manual discount is ₹19,000, GST becomes ₹65,000 and the total becomes ₹4,26,300.
2. **Given** I reject a request, **when** I submit without a reason, **then** I cannot proceed until I add one.
3. **Given** a request untouched for 2 working days, **when** the reminder job runs, **then** I and my manager receive a reminder.

---

### US-10: Send a professional quote PDF
**As a** Sales Executive, **I want** to generate and email a branded PDF quote, **so that** the client receives a clear, official document.

| Field | Value |
|---|---|
| Priority | Must |
| Points | 5 |
| Traces to | BR-08, FR-23 – FR-26, FR-28, FR-29 |

**Acceptance criteria**
1. **Given** a calculated quote, **when** I generate the PDF, **then** it has an ID like `CQ-2026-0004`, issue date, expiry date (issue + 30 days), line items, totals, terms and page numbers.
2. **Given** I email the quote, **when** it is sent, **then** status changes to "Sent" and the email is logged.
3. **Given** a sent quote passes its expiry date without acceptance, **when** the nightly job runs, **then** status changes to "Expired".

---

### US-11: Update rates without IT
**As a** Pricing Admin, **I want** to change base fees, multipliers, tiers and exposure levels with an effective date, **so that** pricing stays current without a software release.

| Field | Value |
|---|---|
| Priority | Must |
| Points | 5 |
| Traces to | BR-09, FR-30 – FR-33 |

**Acceptance criteria**
1. **Given** I change the Flood base fee from ₹18,000 to ₹19,000 effective 01-Jan-2027, **when** I save with a reason, **then** the audit log shows old value, new value, my name, timestamp and reason.
2. **Given** that change, **when** a quote is created on 31-Dec-2026, **then** it uses ₹18,000.
3. **Given** I upload an exposure matrix CSV with an invalid level "Extreme", **when** I validate, **then** the row is rejected and the matrix is not activated.

---

### US-12: Track the sales pipeline
**As the** Head of Sustainability BU, **I want** a dashboard of quotes by status, city, hazard and segment, **so that** I can see where demand and revenue are coming from.

| Field | Value |
|---|---|
| Priority | Should |
| Points | 5 |
| Traces to | BR-10, FR-34 – FR-36 |

**Acceptance criteria**
1. **Given** quotes exist, **when** I open the dashboard, **then** I see counts and values by status, city, hazard, segment and executive.
2. **Given** I filter by "Last 90 days" and "Insurer", **when** the filter applies, **then** all widgets update.
3. **Given** any table, **when** I click "Export", **then** an .xlsx file downloads with the filtered data.

---

### US-13: Show a risk preview in the quote
**As a** marketing lead, **I want** each quote to show exposure levels per hazard per site, **so that** the client sees the value of the assessment before buying.

| Field | Value |
|---|---|
| Priority | Should |
| Points | 2 |
| Traces to | BR-11, FR-07, FR-24 |

**Acceptance criteria**
1. **Given** a quote for Guwahati, **when** the PDF is generated, **then** a "Risk preview" table shows Flood: Very high, Earthquake: Very high, Landslide: High, etc.
2. **Given** the preview, **when** displayed, **then** it carries the note "Indicative exposure. Full results are delivered in the assessment report."

---

### US-14: Keep client data secure
**As a** Sales Manager, **I want** each executive to see only their own quotes, **so that** client information stays confidential.

| Field | Value |
|---|---|
| Priority | Must |
| Points | 3 |
| Traces to | BR-12, FR-37, FR-38 |

**Acceptance criteria**
1. **Given** I am a Sales Executive, **when** I open the quote list, **then** I see only quotes I created.
2. **Given** I am not signed in through SSO, **when** I open any portal URL, **then** I am redirected to the SSO login.

---

### US-15: Revise a quote without losing history
**As a** Sales Executive, **I want** to revise a sent quote as a new version, **so that** I can respond to client changes and still show what was sent before.

| Field | Value |
|---|---|
| Priority | Should |
| Points | 3 |
| Traces to | BR-13, FR-27 |

**Acceptance criteria**
1. **Given** quote CQ-2026-0002 v1 is "Sent", **when** I click "Revise", **then** v2 opens as a Draft and v1 becomes read-only.
2. **Given** v2 is sent, **when** I view the quote history, **then** I see v1 and v2 with their dates and totals.

---

Related documents: [BRD](BRD.md) · [FRS](FRS.md) · [UAT](UAT.md) · [Pricing](PRICING.md)
