---
name: User story
about: Propose a new user story for the ClimaQ Pricing Portal
title: "US-XX: <short title>"
labels: user-story
---

**As a** <role>
**I want** <capability>
**so that** <benefit>

### Acceptance criteria
1. **Given** <context>, **when** <action>, **then** <result>.
2. **Given** <context>, **when** <action>, **then** <result>.

### Details
- Priority (Must / Should / Could):
- Estimate (story points):
- Traces to (BR / FR):
