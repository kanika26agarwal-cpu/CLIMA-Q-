# ClimaQ pricing and quotations (India)

> **Illustrative pricing for a BA case study.** All figures are sample values created to demonstrate requirements and a pricing model. They are not RMSI's commercial rates. Exposure levels are indicative and are not outputs of a hazard model.

[← Back to README](../README.md)

## 1. How a price is calculated

Each hazard assessed at each location is one *assessment line*.

```
Line price  = Hazard base fee × Exposure multiplier × City tier factor × (1 + Scenario uplift)
Subtotal    = Sum of all line prices
Discount    = Subtotal × Volume discount (by number of locations)
Total       = (Subtotal − Discount) + 18% GST
```

Every line price, discount and GST amount is rounded to the nearest ₹100.

**Analogy:** think of a car insurance premium. The base fee is the car model, the exposure multiplier is how risky the roads are, the tier factor is how hard it is to inspect the car, and the scenario uplift is buying extra cover for the future.

### 1.1 Hazard base fees (per location)

| Code | Hazard | Base fee |
|---|---|---:|
| FL | Riverine & pluvial flood | ₹18,000 |
| CY | Cyclone & extreme wind | ₹15,000 |
| HT | Extreme heat | ₹10,000 |
| DR | Drought & water stress | ₹12,000 |
| EQ | Earthquake | ₹14,000 |
| LS | Landslide | ₹13,000 |
| CI | Coastal inundation & sea-level rise | ₹16,000 |

### 1.2 Exposure multiplier

A higher exposure needs finer-resolution modelling and analyst review, so it costs more.

| Exposure level | Multiplier |
|---|---:|
| Low | 1.00 |
| Moderate | 1.15 |
| High | 1.35 |
| Very high | 1.60 |
| Not applicable (e.g. coastal hazard for an inland city) | Not offered |

### 1.3 City tier factor

Reflects data availability. Tier 1 metros have dense observation networks; Tier 3 locations need more data acquisition and validation.

| Tier | Factor | Cities in this sample |
|---|---:|---|
| Tier 1 | 1.00 | Mumbai, Delhi, Chennai, Kolkata, Bengaluru, Hyderabad, Ahmedabad, Pune |
| Tier 2 | 1.10 | Surat, Jaipur, Bhubaneswar, Visakhapatnam, Kochi, Guwahati, Dehradun |
| Tier 3 | 1.20 | Bhuj, Port Blair |

### 1.4 Climate scenario add-on

Baseline (current climate) is included. Adding forward-looking projections under **SSP2-4.5** and **SSP5-8.5** for **2030 and 2050** adds **40%** to every line.

### 1.5 Volume discount

| Locations in one quote | Discount |
|---|---:|
| 1–4 | 0% |
| 5–19 | 10% |
| 20–49 | 15% |
| 50 or more | Enterprise plan, custom quote |

## 2. Plans

| Plan | Best for | What's included | Price |
|---|---|---|---|
| **Site Report** | One-off assessment of a few sites | PDF risk report per site, hazard scores, baseline climate | Pay per assessment line (rate card below) |
| **Portfolio** | Banks and insurers screening 5–49 sites | Dashboard for 5 users, Excel export, quarterly refresh, volume discount | ₹3,00,000 per year platform fee + assessment lines |
| **Enterprise** | 50+ sites, API integration | API access, SSO, custom hazards, dedicated analyst | Custom quote |

## 3. Exposure matrix by city

| City | State | Tier | FL | CY | HT | DR | EQ | LS | CI |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| Mumbai | Maharashtra | 1 | VH | M | M | M | M | M | VH |
| Delhi | Delhi NCT | 1 | H | L | VH | H | H | L | – |
| Chennai | Tamil Nadu | 1 | VH | H | H | H | M | L | VH |
| Kolkata | West Bengal | 1 | VH | H | H | L | M | L | H |
| Bengaluru | Karnataka | 1 | M | L | M | H | L | L | – |
| Hyderabad | Telangana | 1 | H | L | H | H | L | L | – |
| Ahmedabad | Gujarat | 1 | M | M | VH | H | M | L | – |
| Pune | Maharashtra | 1 | M | L | M | M | M | M | – |
| Surat | Gujarat | 2 | VH | M | H | M | M | L | H |
| Jaipur | Rajasthan | 2 | L | L | VH | VH | M | L | – |
| Bhubaneswar | Odisha | 2 | H | VH | H | L | L | L | M |
| Visakhapatnam | Andhra Pradesh | 2 | M | VH | H | M | L | M | VH |
| Kochi | Kerala | 2 | VH | L | M | L | M | M | VH |
| Guwahati | Assam | 2 | VH | L | M | L | VH | H | – |
| Dehradun | Uttarakhand | 2 | M | L | M | L | H | VH | – |
| Bhuj | Gujarat | 3 | L | M | VH | VH | VH | L | M |
| Port Blair | Andaman & Nicobar | 3 | M | H | M | L | VH | M | VH |

L = Low, M = Moderate, H = High, VH = Very high, – = Not applicable

## 4. Rate card: price per location per hazard (baseline climate)

| City | FL | CY | HT | DR | EQ | LS | CI | All applicable hazards |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Mumbai | ₹28,800 | ₹17,300 | ₹11,500 | ₹13,800 | ₹16,100 | ₹14,900 | ₹25,600 | **₹1,28,000** |
| Delhi | ₹24,300 | ₹15,000 | ₹16,000 | ₹16,200 | ₹18,900 | ₹13,000 | – | **₹1,03,400** |
| Chennai | ₹28,800 | ₹20,300 | ₹13,500 | ₹16,200 | ₹16,100 | ₹13,000 | ₹25,600 | **₹1,33,500** |
| Kolkata | ₹28,800 | ₹20,300 | ₹13,500 | ₹12,000 | ₹16,100 | ₹13,000 | ₹21,600 | **₹1,25,300** |
| Bengaluru | ₹20,700 | ₹15,000 | ₹11,500 | ₹16,200 | ₹14,000 | ₹13,000 | – | **₹90,400** |
| Hyderabad | ₹24,300 | ₹15,000 | ₹13,500 | ₹16,200 | ₹14,000 | ₹13,000 | – | **₹96,000** |
| Ahmedabad | ₹20,700 | ₹17,300 | ₹16,000 | ₹16,200 | ₹16,100 | ₹13,000 | – | **₹99,300** |
| Pune | ₹20,700 | ₹15,000 | ₹11,500 | ₹13,800 | ₹16,100 | ₹14,900 | – | **₹92,000** |
| Surat | ₹31,700 | ₹19,000 | ₹14,900 | ₹15,200 | ₹17,700 | ₹14,300 | ₹23,800 | **₹1,36,600** |
| Jaipur | ₹19,800 | ₹16,500 | ₹17,600 | ₹21,100 | ₹17,700 | ₹14,300 | – | **₹1,07,000** |
| Bhubaneswar | ₹26,700 | ₹26,400 | ₹14,900 | ₹13,200 | ₹15,400 | ₹14,300 | ₹20,200 | **₹1,31,100** |
| Visakhapatnam | ₹22,800 | ₹26,400 | ₹14,900 | ₹15,200 | ₹15,400 | ₹16,400 | ₹28,200 | **₹1,39,300** |
| Kochi | ₹31,700 | ₹16,500 | ₹12,700 | ₹13,200 | ₹17,700 | ₹16,400 | ₹28,200 | **₹1,36,400** |
| Guwahati | ₹31,700 | ₹16,500 | ₹12,700 | ₹13,200 | ₹24,600 | ₹19,300 | – | **₹1,18,000** |
| Dehradun | ₹22,800 | ₹16,500 | ₹12,700 | ₹13,200 | ₹20,800 | ₹22,900 | – | **₹1,08,900** |
| Bhuj | ₹21,600 | ₹20,700 | ₹19,200 | ₹23,000 | ₹26,900 | ₹15,600 | ₹22,100 | **₹1,49,100** |
| Port Blair | ₹24,800 | ₹24,300 | ₹13,800 | ₹14,400 | ₹26,900 | ₹17,900 | ₹30,700 | **₹1,52,800** |

## 5. Rate card: with climate scenarios (SSP2-4.5 and SSP5-8.5, 2030 and 2050)

| City | FL | CY | HT | DR | EQ | LS | CI | All applicable hazards |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Mumbai | ₹40,300 | ₹24,200 | ₹16,100 | ₹19,300 | ₹22,500 | ₹20,900 | ₹35,800 | **₹1,79,100** |
| Delhi | ₹34,000 | ₹21,000 | ₹22,400 | ₹22,700 | ₹26,500 | ₹18,200 | – | **₹1,44,800** |
| Chennai | ₹40,300 | ₹28,400 | ₹18,900 | ₹22,700 | ₹22,500 | ₹18,200 | ₹35,800 | **₹1,86,800** |
| Kolkata | ₹40,300 | ₹28,400 | ₹18,900 | ₹16,800 | ₹22,500 | ₹18,200 | ₹30,200 | **₹1,75,300** |
| Bengaluru | ₹29,000 | ₹21,000 | ₹16,100 | ₹22,700 | ₹19,600 | ₹18,200 | – | **₹1,26,600** |
| Hyderabad | ₹34,000 | ₹21,000 | ₹18,900 | ₹22,700 | ₹19,600 | ₹18,200 | – | **₹1,34,400** |
| Ahmedabad | ₹29,000 | ₹24,200 | ₹22,400 | ₹22,700 | ₹22,500 | ₹18,200 | – | **₹1,39,000** |
| Pune | ₹29,000 | ₹21,000 | ₹16,100 | ₹19,300 | ₹22,500 | ₹20,900 | – | **₹1,28,800** |
| Surat | ₹44,400 | ₹26,600 | ₹20,800 | ₹21,300 | ₹24,800 | ₹20,000 | ₹33,300 | **₹1,91,200** |
| Jaipur | ₹27,700 | ₹23,100 | ₹24,600 | ₹29,600 | ₹24,800 | ₹20,000 | – | **₹1,49,800** |
| Bhubaneswar | ₹37,400 | ₹37,000 | ₹20,800 | ₹18,500 | ₹21,600 | ₹20,000 | ₹28,300 | **₹1,83,600** |
| Visakhapatnam | ₹31,900 | ₹37,000 | ₹20,800 | ₹21,300 | ₹21,600 | ₹23,000 | ₹39,400 | **₹1,95,000** |
| Kochi | ₹44,400 | ₹23,100 | ₹17,700 | ₹18,500 | ₹24,800 | ₹23,000 | ₹39,400 | **₹1,90,900** |
| Guwahati | ₹44,400 | ₹23,100 | ₹17,700 | ₹18,500 | ₹34,500 | ₹27,000 | – | **₹1,65,200** |
| Dehradun | ₹31,900 | ₹23,100 | ₹17,700 | ₹18,500 | ₹29,100 | ₹32,000 | – | **₹1,52,300** |
| Bhuj | ₹30,200 | ₹29,000 | ₹26,900 | ₹32,300 | ₹37,600 | ₹21,800 | ₹30,900 | **₹2,08,700** |
| Port Blair | ₹34,800 | ₹34,000 | ₹19,300 | ₹20,200 | ₹37,600 | ₹25,100 | ₹43,000 | **₹2,14,000** |

Prices exclude GST. Machine-readable version: [`data/rate-card.csv`](../data/rate-card.csv).

## 6. Sample quotations

All clients below are fictional.

### CQ-2026-0001: Coastal General Insurance (fictional)

- **Segment:** Insurer – underwriting a warehouse
- **Locations:** 1
- **Climate scenarios:** Yes (+40%)
- **Validity:** 30 days from issue
- **Billing basis:** assessment lines only. The Portfolio plan platform fee, if chosen, is billed separately.

| Site | City | Hazard | Exposure | Price |
|---|---|---|---|---:|
| Ennore warehouse | Chennai | Riverine & pluvial flood | Very high | ₹40,300 |
| Ennore warehouse | Chennai | Cyclone & extreme wind | High | ₹28,400 |
| Ennore warehouse | Chennai | Extreme heat | High | ₹18,900 |
| Ennore warehouse | Chennai | Drought & water stress | High | ₹22,700 |
| Ennore warehouse | Chennai | Earthquake | Moderate | ₹22,500 |
| Ennore warehouse | Chennai | Landslide | Low | ₹18,200 |
| Ennore warehouse | Chennai | Coastal inundation & sea-level rise | Very high | ₹35,800 |
| | | | **Subtotal** | **₹1,86,800** |
| | | | Volume discount (0%) | −₹0 |
| | | | Taxable amount | ₹1,86,800 |
| | | | GST (18%) | ₹33,600 |
| | | | **Total payable** | **₹2,20,400** |

### CQ-2026-0002: Bharat Lending Bank (fictional)

- **Segment:** Bank – collateral portfolio screening
- **Locations:** 5
- **Climate scenarios:** Yes (+40%)
- **Validity:** 30 days from issue
- **Billing basis:** assessment lines only. The Portfolio plan platform fee, if chosen, is billed separately.

| Site | City | Hazard | Exposure | Price |
|---|---|---|---|---:|
| Branch collateral A | Mumbai | Riverine & pluvial flood | Very high | ₹40,300 |
| Branch collateral A | Mumbai | Cyclone & extreme wind | Moderate | ₹24,200 |
| Branch collateral A | Mumbai | Extreme heat | Moderate | ₹16,100 |
| Branch collateral B | Delhi | Riverine & pluvial flood | High | ₹34,000 |
| Branch collateral B | Delhi | Cyclone & extreme wind | Low | ₹21,000 |
| Branch collateral B | Delhi | Extreme heat | Very high | ₹22,400 |
| Branch collateral C | Kolkata | Riverine & pluvial flood | Very high | ₹40,300 |
| Branch collateral C | Kolkata | Cyclone & extreme wind | High | ₹28,400 |
| Branch collateral C | Kolkata | Extreme heat | High | ₹18,900 |
| Branch collateral D | Surat | Riverine & pluvial flood | Very high | ₹44,400 |
| Branch collateral D | Surat | Cyclone & extreme wind | Moderate | ₹26,600 |
| Branch collateral D | Surat | Extreme heat | High | ₹20,800 |
| Branch collateral E | Guwahati | Riverine & pluvial flood | Very high | ₹44,400 |
| Branch collateral E | Guwahati | Cyclone & extreme wind | Low | ₹23,100 |
| Branch collateral E | Guwahati | Extreme heat | Moderate | ₹17,700 |
| | | | **Subtotal** | **₹4,22,600** |
| | | | Volume discount (10%) | −₹42,300 |
| | | | Taxable amount | ₹3,80,300 |
| | | | GST (18%) | ₹68,500 |
| | | | **Total payable** | **₹4,48,800** |

### CQ-2026-0003: Western Auto Components (fictional)

- **Segment:** Manufacturer – plant resilience review
- **Locations:** 3
- **Climate scenarios:** No, baseline only
- **Validity:** 30 days from issue
- **Billing basis:** assessment lines only. The Portfolio plan platform fee, if chosen, is billed separately.

| Site | City | Hazard | Exposure | Price |
|---|---|---|---|---:|
| Plant 1 | Ahmedabad | Extreme heat | Very high | ₹16,000 |
| Plant 1 | Ahmedabad | Drought & water stress | High | ₹16,200 |
| Plant 1 | Ahmedabad | Earthquake | Moderate | ₹16,100 |
| Plant 2 | Pune | Extreme heat | Moderate | ₹11,500 |
| Plant 2 | Pune | Drought & water stress | Moderate | ₹13,800 |
| Plant 2 | Pune | Earthquake | Moderate | ₹16,100 |
| Plant 3 | Bhuj | Extreme heat | Very high | ₹19,200 |
| Plant 3 | Bhuj | Drought & water stress | Very high | ₹23,000 |
| Plant 3 | Bhuj | Earthquake | Very high | ₹26,900 |
| | | | **Subtotal** | **₹1,58,800** |
| | | | Volume discount (0%) | −₹0 |
| | | | Taxable amount | ₹1,58,800 |
| | | | GST (18%) | ₹28,600 |
| | | | **Total payable** | **₹1,87,400** |

## 7. Worked example (one line)

Flood at Chennai with scenarios:

```
₹18,000 (flood base) × 1.60 (Very high) × 1.00 (Tier 1) × 1.40 (scenarios)
= ₹40,320 → rounded to ₹40,300
```

_Regenerate this page after changing any rate with `python tools/quote_engine.py`._
